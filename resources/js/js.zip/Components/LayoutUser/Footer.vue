<template>
    <div class="bg-white p-3 border-top shadow">
        <p class="mb-0 text-center">© 2023 All Right Reserved {{ $page.props.setting.app_name ?? 'Isi Setting Terlebih Dahulu' }}</p>
    </div>
</template>

<script>
    export default {

    }
</script>
